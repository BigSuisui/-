#ifndef __DEMO_H
#define __DEMO_H	 

#include "sys.h"

#define READ	0x03
#define WRITE	0X06


void TestOpr(void);

		 				    
#endif
