#ifndef _CRC16_H
#define _CRC16_H

#include "sys.h"

unsigned int GetCRC16(unsigned char *pPtr,unsigned char ucLen);	/* ���CRC16У��ֵ */

#endif 

