#ifndef __PID_H
#define __PID_H

#include "stm32f10x.h"                  // Device header

extern float PosErr; 
extern float PosLastErr; 
extern float SumError; 
extern float Out_Posion; 
extern float P_Pos; 
extern float I_Pos; 
extern float D_Pos; 
extern int Basis_CCR;


int PosPID(u32 totalPosition, float targetPosition);
void Motor_Stop(void) ;
void Motor_Control(int pulse);



#endif
